<?php
    $ruta = $_SERVER['DOCUMENT_ROOT'] . '/CSE-340-II/phpmotors/snippets/';
    $pages = $_SERVER['DOCUMENT_ROOT'] . '/CSE-340-II/phpmotors/';
?>
    <?php require $ruta . 'header.php'; ?>

    <h1>Here content</h1>

    <?php require $ruta . 'footer.php'; ?>
