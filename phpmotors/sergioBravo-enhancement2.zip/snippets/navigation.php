<div class="bg-gris-mas-fuerte p-3">
    <ul class="d-flex list-unstyled">
        <li><a href="#" class="txt-decoration-none txt-blanco p-2 d-block fs-6">Home</a></li>
        <li><a href="#" class="txt-decoration-none txt-blanco p-2 d-block fs-6">Classic</a></li>
        <li><a href="#" class="txt-decoration-none txt-blanco p-2 d-block fs-6">Sports</a></li>
        <li><a href="#" class="txt-decoration-none txt-blanco p-2 d-block fs-6">SUV</a></li>
        <li><a href="#" class="txt-decoration-none txt-blanco p-2 d-block fs-6">Trucks</a></li>
        <li><a href="#" class="txt-decoration-none txt-blanco p-2 d-block fs-6">Used</a></li>
    </ul>
</div>