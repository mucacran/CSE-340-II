        </main>
        <footer>
        <hr class="bg-gris-mas-fuerte" style="height:5px">
            <div class="bg-blanco p-5">  
                <div>
                    <p class="txt-center txt-gris-mas-fuerte">&copy; PHP Motors, All rights reserved.</p>
                </div>
                <div>
                    <p class="txt-center txt-gris-mas-fuerte">All images used are believed to be in "Fair Use". Please notify the author if any are not and will be removed.</p>
                </div>
                <div>
                    <p class="txt-center txt-gris-mas-fuerte">Last Update: <?php echo date("Y/m/d"); ?> </p>
                </div>
            </div>
        </footer>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js"></script>
<script>
  WebFont.load({
    google: {
      families: ['Share Tech']
    }
  });
</script>    
</body>
</html>