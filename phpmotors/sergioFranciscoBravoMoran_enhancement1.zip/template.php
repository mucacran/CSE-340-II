<?php
    $ruta = $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/';
    $pages = $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/';
?>
    <?php require $ruta . 'header.php'; ?>

    <h1>Here content</h1>

    <?php require $ruta . 'footer.php'; ?>
